require.config({
	
	paths: {
		'Backbone': 'libs/backbone/backbone',
		'jquery': 'libs/jquery/jquery-1.10.1',
		'jqueryMobile': 'libs/jquery/jquery.mobile-1.3.1',
		'json': 'libs/json/json2',
		'underscore': 'libs/underscore/underscore',
		'domReady': 'libs/require/domReady',
        'text': 'libs/require/text',
        'bootstrap': 'libs/bootstrap/bootstrap',
        'app_upgrade': 'library/app_upgrade',
        'syncManager': 'library/syncManager'
	},
	shim: {
		Backbone:{
            deps:['underscore', 'jquery'],
            exports:'Backbone'
        },
        underscore:{
            exports:'_'
        },
        bootstrap: {
            deps:['jquery'],
            exports: 'bootstrap'
        }
    }
});

require(['jquery', 'domReady', 'bootstrap', 'app_upgrade'],
        function($, domReady, bootstrap, app_upgrade) {
        
                function launchApp() {
        
                    //UPGRADE: var upgrador = new app_upgrade();
                    //UPGRADE: upgrador.check(upgraded);
                    require(['view/MainView'], function(MainView) {
                        window.mainView = new MainView();
                        //window.mainView.render();
                    });
                }
        
                /*UPGRADE:
                function upgraded(urls) {
                    console.log("==upgraded(version, urls): "+window.my_config.version+", "+JSON.stringify(urls));
                    //UPGRADE: find someway to use new version
                }
                */
        
                domReady(function() {

                         if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry)/)) {
                            document.addEventListener("deviceready", launchApp, false);
                         } else {
                            launchApp(); //this is the browser
                         }
                });
        }
);
