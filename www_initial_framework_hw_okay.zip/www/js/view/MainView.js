define(['underscore', 'Backbone', 'jquery', 'bootstrap',
        'model/HWCategoryCollection',
        'model/HWCategory',
        'model/HWNewsCollection',
        'model/HWNews',
        'view/ItemView',
        'text!view/MainView.html!strip'
       ],
       
       function(_, Backbone, $, bootstrap, HWCategoryCollection, HWCategory, HWNewsCollection, HWNews, ItemView, MainViewTemplate) {
       
            var MainView = Backbone.View.extend({

                el: 'body',
                
                per_page: 10,
                
                cur_page: 0,
                
                cur_category_id: 0,
                
                categories: [],
                
                news: [],
                
                events: {
                    //'click .news': 'showNews',
                    'click #navigator li a': 'showCategoryNews'
                    //'click #back': 'goBack'
                },
                
                initialize: function(options) {
                    _.bindAll(this, 'render', 'resetNews', 'resetCategories', 'showCategoryNews');
 
                    //fetch categories, news of selected category and render
                    var that = this;
                    that.resetCategories(function() {
                        that.resetNews( function() {
                            that.render();
                        });
                    });
                    
                    this.categories.fetch({reset: true});
                    
                },
                
                //render basic template and this.categories/ this.news
                render: function() {
                    var html = MainViewTemplate;
                    this.$el.html(html);
                    
                    $('.carousel').carousel();
                    
                    //show categories on navigator 
                    _.each(this.categories.models, function(cat) {
                        
                        if (cat.get("real_id") == this.cur_category_id) {
                            $('#navigator').append('<li class="active"><a href="javascript:void(0)" data-cat-id="'+cat.get("real_id")+'">'+cat.get('title')+'</a></li>');
                        } else {
                            $('#navigator').append('<li><a href="javascript:void(0)" data-cat-id="'+cat.get("real_id")+'">'+cat.get('title')+'</a></li>');
                        }
                    });
                    
                    _.each(this.news.models, function(news) {
                        var itemView = new ItemView({model: news});
                        $('#news_list').append(itemView.render().$el);
                    });
                    
                    return this;
                    
                },
                
                resetNews: function(callback) {
                    var that = this;
                    
                    
                    that.news = new HWNewsCollection();
                    that.news.setCurCategoryId(that.cur_category_id);
                    console.log("resetNews:"+ that.news.cur_category_id);
                    
                    that.news.on('reset', function(newsCollection, options) {
                        console.log("on resetNews: ", newsCollection.models.length);
                        that.news = newsCollection;
                        if (typeof callback != 'undefined') {
                            console.log("callback in resetNews");
                            callback();
                        }
                    });
                    
                    that.news.fetch({reset:true});
                },
                
                resetCategories: function(callback) {
                    var that = this;
                    
                    that.categories = new HWCategoryCollection();
                    that.categories.on('reset', function(catCollection, options) {
                        if (typeof catCollection.models == 'undefined' || catCollection.models.length == 0) {
                            return;
                        }
                    
                        //clean categories on navigator
                        that.categories = catCollection;
                    
                        //locate current category id, set to first if not found
                        var found_cur_cat = that.categories.models[0].get("real_id");
                        _.each(that.categories.models, function(cat) {
                            if (cat.get("real_id") == that.cur_category_id) {
                                found_cur_cat = this.cur_category_id;
                            }
                        });
                    
                        if (found_cur_cat != this.cur_category_id) {
                            that.cur_category_id = found_cur_cat;
                        }
                        
                        if (typeof callback != 'undefined') {
                            callback();
                        }
                    }, that);
                    
                },
                
                showCategoryNews: function(evt) {
                    var c = $(evt.currentTarget);
 
                    var that = this;
                    
                    this.cur_category_id = c.attr("data-cat-id");
                    console.log("category id:", this.cur_category_id);
                    this.resetNews(function() {
                        that.render();
                    });
                }
            });
       
       
            return MainView;
       });