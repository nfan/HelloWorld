define(['jquery', 'Backbone', 'underscore',
        'text!view/ItemView.html!strip',
        'view/DetailView'
        ],
        function($, Backbone, _, ItemViewTemplate, DetailView) {

    var ItemView = Backbone.View.extend({
        tagName: 'div',
        className: 'row-fluid',
        template: _.template(ItemViewTemplate),
        events: {
            "click .row-fluid a": 'gotoDetail'
        },
        initialize: function() {
            _.bindAll(this, 'render', 'gotoDetail');
        }, 
        render: function() {
            var html = this.template({news: this.model});
            this.$el.html(html);
            return this;
        },
        gotoDetail: function() {
            var detailView = new DetailView({model:this.model});
            detailView.render(); 
        }
    });
    
    return ItemView;
});