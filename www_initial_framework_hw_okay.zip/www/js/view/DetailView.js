define(['jquery', 'Backbone', 'underscore',
        'text!view/DetailView.html!strip',
        'view/MainView'
        ],
        function($, Backbone, _, DetailViewTemplate, MainView) {

    var DetailView = Backbone.View.extend({
        el:'body',
        template: _.template(DetailViewTemplate),
        
        events: {
            "click .row-fluid a": 'gotoDetail'
        },
        initialize: function() {
            _.bindAll(this, 'render', 'gotoMain');
        }, 
        render: function() {
            var html = this.template({news: this.model});
            this.$el.html(html);
            return this;
        },
        gotoMain: function() {
            var mainView = window.mainView;
            mainView.render();
        }
    });
    
    return DetailView;
});