define(['underscore', 'Backbone',
        'model/HWApp',
        'model/HWNews'
        ],
       
    function(_, Backbone, HWApp, HWNews) {

        var HWNewsCollection = Backbone.Collection.extend({
            model: HWNews,
            cur_category_id: 0,
            
            initialize: function() {
                _.bindAll(this, 'url', 'setCurCategoryId');
            },
            
            url: function() {
                var config = (new HWApp).getInstance();
                return config.get('base_url')+'/hwnews/newslist_json?category_id='+this.cur_category_id;
            },
            
            setCurCategoryId: function(cur_category_id) {
                this.cur_category_id = cur_category_id;
            }
        });
       
       return HWNewsCollection;
    }
);