define(['underscore', 'Backbone'], function(_, Backbone) {

    var HWApp = Backbone.Model.extend({
        defaults: {
            base_url: "http://fannan.co",
            version: "0.0"
        },
        
        getInstance: function() {
            if(typeof window.hw_config == 'undefined') {
                window.hw_config = this;
            }
            
            return window.hw_config;
        }
    });
    
    return HWApp;
});