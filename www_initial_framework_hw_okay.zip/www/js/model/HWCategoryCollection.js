define(['underscore', 'Backbone',
        'model/HWApp',
        'model/HWCategory'
        ],
       
    function(_, Backbone, HWApp, HWCategory) {

        var HWCategoryCollection = Backbone.Collection.extend({
            model: HWCategory,

            url: function() {
                var config = (new HWApp).getInstance();
                return config.get('base_url')+'/hwcategory/categorylist_json';
            }
        });
       
       return HWCategoryCollection;
    }
);