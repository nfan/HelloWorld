define(['underscore', 'Backbone',
        'model/HWApp',
        'model/HWImage'
        ],
       
    function(_, Backbone, HWApp, HWImage) {

        var HWImageCollection = Backbone.Colllection.extend({
            model: HWImage,

            url: function() {
                var config = (new HWApp).getInstance();
                return config.get('base_url')+'/hwimage/imagelist_json';
            }
        });
       
       return HWImageCollection;
    }
);