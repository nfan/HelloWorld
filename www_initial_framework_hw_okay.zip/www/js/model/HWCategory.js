define(['underscore', 'Backbone'], function(_, Backbone) {

    var HWCategory = Backbone.Model.extend({
        defaults: {
            id: '0',
            title: '',
            images: '',
            create_datetim: '',
            update_datetime: ''
        }
    });
    
    return HWCategory;
});