define(['underscore', 'Backbone', 'jquery'], function(_, Backbone, $) {

    var HWImage = Backbone.Model.extend({
        defaults: {
            id: '0',
            name: '',
            path: '#'
        }

    });
    
    return HWImage;
});