define(['underscore', 'Backbone'], function(_, Backbone) {

    var HWNews = Backbone.Model.extend({
        defaults: {
            id: '0',
            title: '',
            content: '',
            create_datetim: '',
            update_datetime: ''
        },
        
        initialize: function() {
            _.bindAll(this, 'getSmallImage', 'getLargeImage');
        },
        
        getSmallImage: function() {
            var ret = "#";
            
            return ret;
        },
        
        getLargeImage: function() {
            var ret = "#";
            
            return ret;
        }

    });
    
    return HWNews;
});